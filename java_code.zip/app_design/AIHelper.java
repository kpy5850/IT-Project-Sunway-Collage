package com.example.app_design;

import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import okhttp3.*;

public class AIHelper {
    private static final String API_KEY = "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";
    private static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";

    public interface AIResponseListener {
        void onResponse(String answer);
        void onError(String error);
    }

    public static void askAI(String question, AIResponseListener listener) {
        sendRequest(question, null, listener);
    }

    public static void askAIWithImage(Bitmap bitmap, String prompt, AIResponseListener listener) {
        String base64Image = encodeImageToBase64(bitmap);
        sendRequest(prompt, base64Image, listener);
    }

    private static void sendRequest(String text, String base64Image, AIResponseListener listener) {
        OkHttpClient client = new OkHttpClient();
        MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");

        try {
            JSONObject root = new JSONObject();
            root.put("model", "google/gemini-2.0-flash-001");

            JSONArray messages = new JSONArray();
            JSONObject message = new JSONObject();
            message.put("role", "user");

            JSONArray contentArray = new JSONArray();

            JSONObject textPart = new JSONObject();
            textPart.put("type", "text");
            textPart.put("text", text);
            contentArray.put(textPart);

            if (base64Image != null) {
                JSONObject imagePart = new JSONObject();
                imagePart.put("type", "image_url");
                JSONObject imageUrl = new JSONObject();
                imageUrl.put("url", "data:image/jpeg;base64," + base64Image);
                imagePart.put("image_url", imageUrl);
                contentArray.put(imagePart);
            }

            message.put("content", contentArray);
            messages.put(message);
            root.put("messages", messages);

            RequestBody body = RequestBody.create(JSON_TYPE, root.toString());
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("Authorization", "Bearer " + API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    listener.onError("网络连接失败: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String responseBody = response.body().string();
                    if (!response.isSuccessful()) {
                        listener.onError("API错误: " + response.code() + " - " + responseBody);
                        return;
                    }
                    try {
                        JSONObject obj = new JSONObject(responseBody);
                        String aiResponse = obj.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("message")
                                .getString("content");
                        listener.onResponse(aiResponse.trim());
                    } catch (Exception e) {
                        listener.onError("解析失败: " + e.getMessage());
                    }
                }
            });

        } catch (Exception e) {
            listener.onError("构造请求失败: " + e.getMessage());
        }
    }

    private static String encodeImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream);
        byte[] byteArray = outputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.NO_WRAP);
    }
}
